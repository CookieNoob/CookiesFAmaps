   local ScenarioUtils = import('/lua/sim/ScenarioUtilities.lua')
   
   function OnPopulate()
   	ScenarioUtils.InitializeArmies()
    ScenarioUtils.CreateArmyGroup('ARMY_1', 'Initial', false)
   end
   
   function OnStart(self)
   end
   
